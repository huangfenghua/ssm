/*
SQLyog Ultimate - MySQL GUI v8.2 
MySQL - 5.5.47 : Database - numysql
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`numysql` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `numysql`;

/*Table structure for table `smbms_user` */

DROP TABLE IF EXISTS `smbms_user`;

CREATE TABLE `smbms_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userCode` varchar(50) NOT NULL,
  `userName` varchar(20) NOT NULL,
  `userPassword` varchar(50) NOT NULL,
  `birthday` date NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `userRole` int(11) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userRoleName` varchar(20) NOT NULL,
  `statu` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

/*Data for the table `smbms_user` */

insert  into `smbms_user`(`id`,`userCode`,`userName`,`userPassword`,`birthday`,`phone`,`address`,`userRole`,`creationDate`,`userRoleName`,`statu`) values (2,'2','admin','96e79218965eb72c92a549dd5a330112','2017-06-09','18250728973','1',1,'2018-09-09 00:00:00','系统管理员','1'),(3,'3','x','96e79218965eb72c92a549dd5a330112','2015-05-08','11','11',2,'2019-09-09 00:00:00','代理商','3'),(4,'2','adminc','1','2019-09-09','22','33',2,'2015-08-09 00:00:00','管理员','0'),(12,'76a8cc18-85af-11e8-9e7b-00e04c362470','1','96e79218965eb72c92a549dd5a330112','2018-07-12','1','1',1,'0000-00-00 00:00:00','代理商','3'),(13,'9915fdec-85b2-11e8-9e7b-00e04c362470','xiaoyou','1234','2018-07-12','12345678912','11',1,'0000-00-00 00:00:00','代理商','0'),(14,'653406e9-85b3-11e8-9e7b-00e04c362470','12453452','1234','1970-01-01','12345678912','2898989@qq.com',1,'2018-07-12 17:10:17','代理商','0'),(15,'0bb933d9-85be-11e8-9e7b-00e04c362470','text1','1','1970-01-01','12345678912','1',1,'2018-07-12 18:26:31','代理商','0');

/*Table structure for table `sys_app_user` */

DROP TABLE IF EXISTS `sys_app_user`;

CREATE TABLE `sys_app_user` (
  `USER_ID` varchar(100) NOT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `RIGHTS` varchar(255) DEFAULT NULL,
  `ROLE_ID` varchar(100) DEFAULT NULL,
  `LAST_LOGIN` varchar(255) DEFAULT NULL,
  `IP` varchar(100) DEFAULT NULL,
  `STATUS` varchar(32) DEFAULT NULL,
  `BZ` varchar(255) DEFAULT NULL,
  `PHONE` varchar(100) DEFAULT NULL,
  `SFID` varchar(100) DEFAULT NULL,
  `START_TIME` varchar(100) DEFAULT NULL,
  `END_TIME` varchar(100) DEFAULT NULL,
  `YEARS` int(10) DEFAULT NULL,
  `NUMBER` varchar(100) DEFAULT NULL,
  `EMAIL` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_app_user` */

insert  into `sys_app_user`(`USER_ID`,`USERNAME`,`PASSWORD`,`NAME`,`RIGHTS`,`ROLE_ID`,`LAST_LOGIN`,`IP`,`STATUS`,`BZ`,`PHONE`,`SFID`,`START_TIME`,`END_TIME`,`YEARS`,`NUMBER`,`EMAIL`) values ('04762c0b28b643939455c7800c2e2412','dsfsd','f1290186a5d0b1ceab27f4e77c0c5d68','w','','55896f5ce3c0494fa6850775a4e29ff6','','','0','','18766666666','','','',0,'001','18766666666@qq.com'),('3faac8fe5c0241e593e0f9ea6f2d5870','dsfsdf','f1290186a5d0b1ceab27f4e77c0c5d68','wewe','','68f23fc0caee475bae8d52244dea8444','','','1','','18767676767','','','',0,'wqwe','qweqwe@qq.com');

/*Table structure for table `sys_bank` */

DROP TABLE IF EXISTS `sys_bank`;

CREATE TABLE `sys_bank` (
  `id` varchar(100) NOT NULL,
  `username` varchar(20) NOT NULL,
  `u_id` char(18) NOT NULL,
  `bankCard` varchar(100) NOT NULL,
  `USEr_ID` int(11) NOT NULL,
  `phone` varchar(32) NOT NULL,
  `statu` varchar(10) NOT NULL COMMENT '1。通过2.审核3.打回0.未认证',
  `fu_img` varchar(200) NOT NULL,
  `fb_img` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_bank` */

insert  into `sys_bank`(`id`,`username`,`u_id`,`bankCard`,`USEr_ID`,`phone`,`statu`,`fu_img`,`fb_img`) values ('0741922c377846b383a633cd8e242442','adminc12','422423196406010078','123456789132456798',3,'18250728973','3','/images/3a59f2dde2a94f15a18045d9d6af510f.jpeg','/images/29811bbbf1444a7fad06895c93316de8.jpeg'),('ea7b3fac609c4e5eb1bbc0a5887b6d96','ccc1','422423196406010078','123456789132456798',3,'18250728973','1','/images/38a8e294c6f24addaad9880d663d95de.jpeg','/images/a384fd090e2d4cdf91f8b9aad11786ef.jpeg'),('b2b5c9ffe83d4f1ca1585923ed0b185b','ccc4343','422423196406010078','123456789132456798',3,'18250728972','3','/images/f91e93960c0349678c20fcc48a01c615.jpeg','/images/457e77e495c645f79eced66586a08808.jpeg'),('72e1db95de1649de8e7ea440b99c7878','1234567891','422423196406010078','123456789132456798',3,'18250728972','3','/images/ea713b5ede93499a8b5b8496b2485884.jpeg','/images/8b67ff8a43a34685a157b95fe840b6f0.jpeg'),('26237618c29f4cdbbf18b81e25a0ab55','14324','422423196406010078','123456789132456798',3,'18250728972','2','/images/133f2c4d1dec4d1399a421220af1f2a6.jpeg','/images/35ffabfe94c3476b9eb6df7ab424028d.jpeg'),('33212fb2ebed4d77b98b9ee29e75bcb2','1','422423196406010078','123456789132456798',2,'18250728972','1','/images/6e5a3d7a9ef3474ba120a38e918f1d1a.jpeg','/images/6c2c2c07d86b4ee5aaa23e18f0765f07.jpeg'),('ef0182688c2340e4b0ccc6585819a72a','1','422423196406010078','123456789132456798',12,'18250728972','3','/images/583d0688e65f40bfa4be85ea125a005b.jpeg','/images/7ddcd21609dc4b41b339254c551e9215.jpeg');

/*Table structure for table `sys_dictionaries` */

DROP TABLE IF EXISTS `sys_dictionaries`;

CREATE TABLE `sys_dictionaries` (
  `ZD_ID` varchar(100) NOT NULL,
  `NAME` varchar(100) DEFAULT NULL,
  `BIANMA` varchar(100) DEFAULT NULL,
  `ORDY_BY` int(10) DEFAULT NULL,
  `PARENT_ID` varchar(100) DEFAULT NULL,
  `JB` int(10) DEFAULT NULL,
  `P_BM` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`ZD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_dictionaries` */

insert  into `sys_dictionaries`(`ZD_ID`,`NAME`,`BIANMA`,`ORDY_BY`,`PARENT_ID`,`JB`,`P_BM`) values ('212a6765fddc4430941469e1ec8c8e6c','人事部','001',1,'c067fdaf51a141aeaa56ed26b70de863',2,'BM_001'),('3cec73a7cc8a4cb79e3f6ccc7fc8858c','行政部','002',2,'c067fdaf51a141aeaa56ed26b70de863',2,'BM_002'),('48724375640341deb5ef01ac51a89c34','北京','dq001',1,'cdba0b5ef20e4fc0a5231fa3e9ae246a',2,'DQ_dq001'),('5a1547632cca449db378fbb9a042b336','研发部','004',4,'c067fdaf51a141aeaa56ed26b70de863',2,'BM_004'),('7f9cd74e60a140b0aea5095faa95cda3','财务部','003',3,'c067fdaf51a141aeaa56ed26b70de863',2,'BM_003'),('b861bd1c3aba4934acdb5054dd0d0c6e','科技不','kj',7,'c067fdaf51a141aeaa56ed26b70de863',2,'BM_kj'),('c067fdaf51a141aeaa56ed26b70de863','部门','BM',1,'0',1,'BM'),('cdba0b5ef20e4fc0a5231fa3e9ae246a','地区','DQ',2,'0',1,'DQ'),('f184bff5081d452489271a1bd57599ed','上海','SH',2,'cdba0b5ef20e4fc0a5231fa3e9ae246a',2,'DQ_SH'),('f30bf95e216d4ebb8169ff0c86330b8f','客服部','006',6,'c067fdaf51a141aeaa56ed26b70de863',2,'BM_006');

/*Table structure for table `sys_gl_qx` */

DROP TABLE IF EXISTS `sys_gl_qx`;

CREATE TABLE `sys_gl_qx` (
  `GL_ID` varchar(100) NOT NULL,
  `ROLE_ID` varchar(100) DEFAULT NULL,
  `FX_QX` int(10) DEFAULT NULL,
  `FW_QX` int(10) DEFAULT NULL,
  `QX1` int(10) DEFAULT NULL,
  `QX2` int(10) DEFAULT NULL,
  `QX3` int(10) DEFAULT NULL,
  `QX4` int(10) DEFAULT NULL,
  PRIMARY KEY (`GL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_gl_qx` */

insert  into `sys_gl_qx`(`GL_ID`,`ROLE_ID`,`FX_QX`,`FW_QX`,`QX1`,`QX2`,`QX3`,`QX4`) values ('1','2',1,1,1,1,1,1),('2','1',0,0,0,0,1,1),('204d7ec81d1b4b189594c6fffa9bf4d5','1',0,0,0,0,0,0),('24d34eae35c84a0fb7f6021ba94468d6','1',0,0,0,0,0,0),('55896f5ce3c0494fa6850775a4e29ff6','7',0,0,1,0,0,0),('68f23fc0caee475bae8d52244dea8444','7',0,0,1,0,0,0),('7dfd8d1f7b6245d283217b7e63eec9b2','1',0,0,0,0,0,0),('ac66961adaa2426da4470c72ffeec117','1',0,0,0,0,0,0),('b0c77c29dfa140dc9b14a29c056f824f','7',1,0,1,0,0,0),('b2f0048f55b4461aab4f303efe129689','0',0,0,0,0,0,0),('e67d562208f14f8e974affcd1555b1aa','b2f0048f55b4461aab4f303efe129689',0,0,0,0,0,0),('e74f713314154c35bd7fc98897859fe3','6',1,1,1,1,0,0),('e7d12802dfc14fbbb853577d50be3f8a','1',0,0,0,0,0,0),('f944a9df72634249bbcb8cb73b0c9b86','7',1,1,1,0,0,0);

/*Table structure for table `sys_menu` */

DROP TABLE IF EXISTS `sys_menu`;

CREATE TABLE `sys_menu` (
  `MENU_ID` int(11) NOT NULL,
  `MENU_NAME` varchar(255) DEFAULT NULL,
  `MENU_URL` varchar(255) DEFAULT NULL,
  `PARENT_ID` varchar(100) DEFAULT NULL,
  `MENU_ORDER` varchar(100) DEFAULT NULL,
  `MENU_ICON` varchar(30) DEFAULT NULL,
  `MENU_TYPE` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`MENU_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_menu` */

insert  into `sys_menu`(`MENU_ID`,`MENU_NAME`,`MENU_URL`,`PARENT_ID`,`MENU_ORDER`,`MENU_ICON`,`MENU_TYPE`) values (1,'系统管理','user/listUsers.do','0','1','icon-desktop','2'),(2,'权限管理','role.do','1','2',NULL,'2'),(5,'系统用户','user/listUsers.do','1','3',NULL,'2'),(6,'商户管理','#','0','2','icon-list-alt','2'),(7,'代理商管理','user/listUsers.do','6','1',NULL,'2'),(8,'性能监控','druid/index.html','9','1',NULL,'2'),(9,'系统工具','#','0','3','icon-th','2'),(10,'接口测试','tool/interfaceTest.do','9','2',NULL,'2'),(11,'发送邮件','tool/goSendEmail.do','9','3',NULL,'2'),(12,'置二维码','tool/goTwoDimensionCode.do','9','4',NULL,'2'),(13,'多级别树','tool/ztree.do','9','5',NULL,'2'),(14,'地图工具','tool/map.do','9','6',NULL,'2'),(15,'微信管理','#','0','2','icon-comments','2'),(16,'文本回复','textmsg/list.do','15','2',NULL,'2'),(17,'应用命令','command/list.do','15','4',NULL,'2'),(18,'图文回复','imgmsg/list.do','15','3',NULL,'2'),(19,'关注回复','textmsg/goSubscribe.do','15','1',NULL,'2'),(21,'打印测试','tool/printTest.do','9','7',NULL,'2'),(22,'部门管理',NULL,'0','2',NULL,'2'),(23,'认证管理',NULL,'22','2',NULL,'2');

/*Table structure for table `sys_role` */

DROP TABLE IF EXISTS `sys_role`;

CREATE TABLE `sys_role` (
  `ROLE_ID` varchar(100) NOT NULL,
  `ROLE_NAME` varchar(100) DEFAULT NULL,
  `RIGHTS` varchar(255) DEFAULT NULL,
  `PARENT_ID` varchar(100) DEFAULT NULL,
  `ADD_QX` varchar(255) DEFAULT NULL,
  `DEL_QX` varchar(255) DEFAULT NULL,
  `EDIT_QX` varchar(255) DEFAULT NULL,
  `CHA_QX` varchar(255) DEFAULT NULL,
  `QX_ID` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_role` */

insert  into `sys_role`(`ROLE_ID`,`ROLE_NAME`,`RIGHTS`,`PARENT_ID`,`ADD_QX`,`DEL_QX`,`EDIT_QX`,`CHA_QX`,`QX_ID`) values ('05beb9e5-88e6-11e8-8a12-00e04c362470','超级会员助1234','6,7,22,23','0','0','0','0','0','0'),('1','','6,7,22,23','0','1','1','1','1','1'),('135d81c1-88e8-11e8-8a12-00e04c362470','123','1,2,5,6,7,22,23','0','0','0','0','0','0'),('2','代理商','22,23','0','0','0','0','0','0'),('5e602d4c-88e7-11e8-8a12-00e04c362470','管理员C','1,2,5','0','0','0','0','0','0');

/*Table structure for table `sys_user` */

DROP TABLE IF EXISTS `sys_user`;

CREATE TABLE `sys_user` (
  `USER_ID` varchar(100) NOT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `RIGHTS` varchar(255) DEFAULT NULL,
  `ROLE_ID` varchar(100) DEFAULT NULL,
  `LAST_LOGIN` varchar(255) DEFAULT NULL,
  `IP` varchar(100) DEFAULT NULL,
  `STATUS` varchar(32) DEFAULT NULL,
  `BZ` varchar(255) DEFAULT NULL,
  `SKIN` varchar(100) DEFAULT NULL,
  `EMAIL` varchar(32) DEFAULT NULL,
  `NUMBER` varchar(100) DEFAULT NULL,
  `PHONE` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_user` */

insert  into `sys_user`(`USER_ID`,`USERNAME`,`PASSWORD`,`NAME`,`RIGHTS`,`ROLE_ID`,`LAST_LOGIN`,`IP`,`STATUS`,`BZ`,`SKIN`,`EMAIL`,`NUMBER`,`PHONE`) values ('1','admin','74d7c8a3426acbbfabfdc457ab44d14332388033','系统管理员','1133671055321055258374707980945218933803269864762743594642571294','1','2018-07-13 16:20:01','0:0:0:0:0:0:0:1','0','最高统治者','default','admin@main.com','001','18788888888'),('e91e65e3fa9f4ef8a9cf70507694836e','df','c38da7a049e5889c83149cc6ea34b06533346f02','1','','e7d12802dfc14fbbb853577d50be3f8a','','','1','e','default','2889006661@qq.com','121','12345678945');

/*Table structure for table `sys_user_qx` */

DROP TABLE IF EXISTS `sys_user_qx`;

CREATE TABLE `sys_user_qx` (
  `U_ID` varchar(100) NOT NULL,
  `C1` int(10) DEFAULT NULL,
  `C2` int(10) DEFAULT NULL,
  `C3` int(10) DEFAULT NULL,
  `C4` int(10) DEFAULT NULL,
  `Q1` int(10) DEFAULT NULL,
  `Q2` int(10) DEFAULT NULL,
  `Q3` int(10) DEFAULT NULL,
  `Q4` int(10) DEFAULT NULL,
  PRIMARY KEY (`U_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `sys_user_qx` */

insert  into `sys_user_qx`(`U_ID`,`C1`,`C2`,`C3`,`C4`,`Q1`,`Q2`,`Q3`,`Q4`) values ('1',1,0,0,0,0,0,0,0),('2',1,1,1,1,1,1,1,1),('204d7ec81d1b4b189594c6fffa9bf4d5',0,0,0,0,0,0,0,0),('24d34eae35c84a0fb7f6021ba94468d6',0,0,0,0,0,0,0,0),('55896f5ce3c0494fa6850775a4e29ff6',0,0,0,0,0,0,0,0),('68f23fc0caee475bae8d52244dea8444',0,0,0,0,0,0,0,0),('7dfd8d1f7b6245d283217b7e63eec9b2',0,0,0,0,0,0,0,0),('ac66961adaa2426da4470c72ffeec117',0,0,0,0,0,0,0,0),('b0c77c29dfa140dc9b14a29c056f824f',0,0,0,0,0,0,0,0),('b2f0048f55b4461aab4f303efe129689',0,0,0,0,0,0,0,0),('e67d562208f14f8e974affcd1555b1aa',0,0,0,0,0,0,0,0),('e74f713314154c35bd7fc98897859fe3',0,0,0,0,0,0,0,0),('e7d12802dfc14fbbb853577d50be3f8a',0,0,0,0,0,0,0,0),('f944a9df72634249bbcb8cb73b0c9b86',0,0,0,0,0,0,0,0);

/*Table structure for table `tb_pictures` */

DROP TABLE IF EXISTS `tb_pictures`;

CREATE TABLE `tb_pictures` (
  `PICTURES_ID` varchar(100) NOT NULL,
  `TITLE` varchar(255) DEFAULT NULL COMMENT '标题',
  `NAME` varchar(255) DEFAULT NULL COMMENT '文件名',
  `PATH` varchar(255) DEFAULT NULL COMMENT '路径',
  `CREATETIME` varchar(255) DEFAULT NULL COMMENT '创建时间',
  `MASTER_ID` varchar(255) DEFAULT NULL COMMENT '属于',
  `BZ` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`PICTURES_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tb_pictures` */

insert  into `tb_pictures`(`PICTURES_ID`,`TITLE`,`NAME`,`PATH`,`CREATETIME`,`MASTER_ID`,`BZ`) values ('034aab1b89f744fb9635798e0f7d323f','图片','c83e3ec4027e49a9a96e347939d140f5.jpg','20180629/c83e3ec4027e49a9a96e347939d140f5.jpg','2018-06-29 09:32:22','1','图片管理处上传'),('04668c4f6a4348cc9568d21a69c37d40','图片','1bafa6d663c742679c444039f448c5f6.jpeg','20180629/1bafa6d663c742679c444039f448c5f6.jpeg','2018-06-29 09:32:23','1','图片管理处上传'),('128d6980bb4b4dcf811e5281e47d9735','图片','268debef510341da9fa51e31ba81c8a2.jpg','20180629/268debef510341da9fa51e31ba81c8a2.jpg','2018-06-29 09:32:18','1','图片管理处上传'),('1d16c4e6ac2d46fda5802462819b3162','图片','ef09a150ba8f4f36864fbfa6540ffda8.jpg','20150803/ef09a150ba8f4f36864fbfa6540ffda8.jpg','2015-08-03 14:31:32','1','图片管理处上传'),('21707616303b4a0a823b18fd4639bdd4','图片','ea389e5aeca2434cb531d5e549ab19a9.jpg','20180629/ea389e5aeca2434cb531d5e549ab19a9.jpg','2018-06-29 09:32:20','1','图片管理处上传'),('232f44f76df84522b9877e2e8c15febf','图片','c1d0766ed6e045028dc82629dd326143.jpg','20180629/c1d0766ed6e045028dc82629dd326143.jpg','2018-06-29 09:32:26','1','图片管理处上传'),('30fcae2709294bac82a0c28c124f364f','图片','3aef9a783e224b5291f792532e9bd651.jpg','20180629/3aef9a783e224b5291f792532e9bd651.jpg','2018-06-29 09:32:20','1','图片管理处上传'),('3415236199d44254a10dfcb3c1297750','图片','354d35c2b57b4acfa7375f82fd82d1ba.jpg','20180629/354d35c2b57b4acfa7375f82fd82d1ba.jpg','2018-06-29 09:32:25','1','图片管理处上传'),('3bdb19346f6640edb196c41a727aecd7','图片','85305ece595546d98a3f60eb7cce65c3.jpg','20180629/85305ece595546d98a3f60eb7cce65c3.jpg','2018-06-29 09:32:23','1','图片管理处上传'),('3f0cff993019418abaeab739d655f3fc','图片','dbb9fe1aaec94b61bb7d88ba64f249e0.png','20180629/dbb9fe1aaec94b61bb7d88ba64f249e0.png','2018-06-29 09:32:23','1','图片管理处上传'),('3f43abec96344d76914bf68e5008eee2','图片','533eb3dd12464464930e2cd66f69566a.jpg','20180629/533eb3dd12464464930e2cd66f69566a.jpg','2018-06-29 09:32:19','1','图片管理处上传'),('4060e6ad15444f5a8224e250b9f9542f','图片','418c1a4d2a3a40c496e20ab786a62f30.jpg','20180629/418c1a4d2a3a40c496e20ab786a62f30.jpg','2018-06-29 09:32:20','1','图片管理处上传'),('413b89fdc34541a4adf78ec0fd68a8e5','图片','0443402b7c704b2d8f381d5eb6eca36a.jpg','20180629/0443402b7c704b2d8f381d5eb6eca36a.jpg','2018-06-29 09:32:24','1','图片管理处上传'),('43fb90aef77a44af96969ca2e56e0805','图片','21994fc342ad40a9b74f7d1921a71d18.jpg','20180629/21994fc342ad40a9b74f7d1921a71d18.jpg','2018-06-29 09:32:21','1','图片管理处上传'),('455b107a73924d2683b63043977f7b2d','图片','20ad1829dab64060ac06f76895ab14b7.jpg','20180629/20ad1829dab64060ac06f76895ab14b7.jpg','2018-06-29 09:32:25','1','图片管理处上传'),('481b83e345104043a3a7da7ab7df5a9b','图片','1cca7e62d94740ef8aa80845675ff50f.jpg','20180629/1cca7e62d94740ef8aa80845675ff50f.jpg','2018-06-29 09:32:22','1','图片管理处上传'),('50f36d26bc89474983ee56ef695a8993','图片','dbbd7dff36c74046815f7dd0b98c245e.jpg','20180629/dbbd7dff36c74046815f7dd0b98c245e.jpg','2018-06-29 09:32:24','1','图片管理处上传'),('571aaafd701a45b7a04a8517dc8f6193','图片','fc41f6bea3c546719f6e844423af8e3e.jpg','20180629/fc41f6bea3c546719f6e844423af8e3e.jpg','2018-06-29 09:30:40','1','图片管理处上传'),('5dafb0cbbec5447db6b754a9bb439d59','图片','3b7afa3a2eeb46058b78011865032b3e.jpg','20180629/3b7afa3a2eeb46058b78011865032b3e.jpg','2018-06-29 09:32:23','1','图片管理处上传'),('672a86a83e814eabae6a12e5a0296436','图片','2c68ee2b734c45548b221cffbe30f706.jpg','20180629/2c68ee2b734c45548b221cffbe30f706.jpg','2018-06-29 09:32:19','1','图片管理处上传'),('813daad0eeec48e88be41cbd77e6daf2','图片','1e448c22adf944e496e1c5d2dd823c79.jpg','20180629/1e448c22adf944e496e1c5d2dd823c79.jpg','2018-06-29 09:32:20','1','图片管理处上传'),('81f8d5473fe44227a70fcb13b0c5236a','图片','6159c915402647f4ae4ce529e6742950.jpg','20180629/6159c915402647f4ae4ce529e6742950.jpg','2018-06-29 09:30:48','1','图片管理处上传'),('88c8d9933fab494489f8d64bd63ea831','图片','c18446c6dc304b95ba7210a0f62a5a04.jpg','20180629/c18446c6dc304b95ba7210a0f62a5a04.jpg','2018-06-29 09:32:24','1','图片管理处上传'),('8bfdebf5ad754592b7e5e3d5c071496a','图片','e0464bee8e70417084491d323e11427d.jpg','20180629/e0464bee8e70417084491d323e11427d.jpg','2018-06-29 09:32:17','1','图片管理处上传'),('9220d428301845aa8665ce5e27615e70','图片','ef7a2af78c3c4144865e8583f6620ce6.jpg','20180629/ef7a2af78c3c4144865e8583f6620ce6.jpg','2018-06-29 09:32:25','1','图片管理处上传'),('97b2f47ae8db4015bb2757e8591a3715','图片','f52e573572674922a324b5abdf0fcba9.jpg','20180629/f52e573572674922a324b5abdf0fcba9.jpg','2018-06-29 09:32:25','1','图片管理处上传'),('9a12104e679543de8da46402c1328059','图片','dffd938bf29a4703bb5f80509dbd62eb.jpg','20180629/dffd938bf29a4703bb5f80509dbd62eb.jpg','2018-06-29 09:32:19','1','图片管理处上传'),('9a712dad265b48efa6c145f953421d16','图片','78e878e9e0494a73af9bb488aeadf1dc.jpg','20180629/78e878e9e0494a73af9bb488aeadf1dc.jpg','2018-06-29 09:32:21','1','图片管理处上传'),('a79220136b3642dcad99b844f93c5d90','图片','e59c0ee1950b445286aa2bfc76081f8a.PNG','20180629/e59c0ee1950b445286aa2bfc76081f8a.PNG','2018-06-29 09:32:25','1','图片管理处上传'),('aa07d74f97fe4171be10067f6e738820','图片','c238f8ac2343484daee37c70855c217a.jpg','20150803/c238f8ac2343484daee37c70855c217a.jpg','2015-08-03 14:33:08','1','图片管理处上传'),('ac0e532ec1d146e9866721e171de28b6','图片','fa570f7ae4bf481fa067d6342b8f79c5.jpg','20180629/fa570f7ae4bf481fa067d6342b8f79c5.jpg','2018-06-29 09:32:18','1','图片管理处上传'),('bcca144277404b6fa1cb351d13f45fbc','图片','903f2e460b994f21bed9bd4e03fecd52.png','20180629/903f2e460b994f21bed9bd4e03fecd52.png','2018-06-29 09:32:23','1','图片管理处上传'),('bd0f0dbf926b41c986e14d7e3008e65a','图片','f91e764e253f4de384bec4c7e6342af3.jpg','20150803/f91e764e253f4de384bec4c7e6342af3.jpg','2015-08-03 14:31:32','1','图片管理处上传'),('cb093dbd033646a8bb792c55e5a17693','图片','8fb3a79fa850482baf01729f2674459b.jpg','20180629/8fb3a79fa850482baf01729f2674459b.jpg','2018-06-29 09:32:21','1','图片管理处上传'),('db036416bd5b4d588bf7c07c11fa56a4','图片','25107bf567354e5f94de03b6397f1e1c.jpg','20180629/25107bf567354e5f94de03b6397f1e1c.jpg','2018-06-29 09:32:23','1','图片管理处上传'),('dd6b39635ec34635bbb3852f0966127d','图片','a50170fb1f8d45f495b692aa7feaa1df.jpg','20180629/a50170fb1f8d45f495b692aa7feaa1df.jpg','2018-06-29 09:32:23','1','图片管理处上传'),('e3cab9b10c834b9ea21f4baf1cef6f1c','图片','1bb93f149fdd476f8bb31dc710dae9a6.jpg','20180629/1bb93f149fdd476f8bb31dc710dae9a6.jpg','2018-06-29 09:32:22','1','图片管理处上传'),('e9885312df6c45068cca1b3043949dc1','图片','8e920256cb814cf69f0a708d412e03b2.jpg','20180629/8e920256cb814cf69f0a708d412e03b2.jpg','2018-06-29 09:32:19','1','图片管理处上传'),('ef23bac8f4ae4a81a6b80859e329dd6c','图片','560b26c3b0084667b7bc4e350e8cf1a1.jpg','20180629/560b26c3b0084667b7bc4e350e8cf1a1.jpg','2018-06-29 09:32:25','1','图片管理处上传'),('f14a0398e4074489ad2689eeb035d21f','图片','2ad1d079f0fb497a9f33780aad79b8f7.jpeg','20180629/2ad1d079f0fb497a9f33780aad79b8f7.jpeg','2018-06-29 09:32:23','1','图片管理处上传'),('f1c14217710447548c7f0a71b9e00ecb','图片','f8b5cbf249c24d418cad2956f64aed6f.jpg','20180629/f8b5cbf249c24d418cad2956f64aed6f.jpg','2018-06-29 09:32:25','1','图片管理处上传'),('f6a89233bbe143388d33ffa4308dd57d','图片','a71565631edb48b6830b1524bae61ae9.jpg','20180629/a71565631edb48b6830b1524bae61ae9.jpg','2018-06-29 09:32:25','1','图片管理处上传'),('ff74823308d54128a797660ac049fcca','图片','19c9584477a84f40ac9f95668e726431.jpg','20180629/19c9584477a84f40ac9f95668e726431.jpg','2018-06-29 09:30:18','1','图片管理处上传');

/*Table structure for table `weixin_command` */

DROP TABLE IF EXISTS `weixin_command`;

CREATE TABLE `weixin_command` (
  `COMMAND_ID` varchar(100) NOT NULL,
  `KEYWORD` varchar(255) DEFAULT NULL COMMENT '关键词',
  `COMMANDCODE` varchar(255) DEFAULT NULL COMMENT '应用路径',
  `CREATETIME` varchar(255) DEFAULT NULL COMMENT '创建时间',
  `STATUS` int(1) NOT NULL COMMENT '状态',
  `BZ` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`COMMAND_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `weixin_command` */

insert  into `weixin_command`(`COMMAND_ID`,`KEYWORD`,`COMMANDCODE`,`CREATETIME`,`STATUS`,`BZ`) values ('2636750f6978451b8330874c9be042c2','锁定服务器','rundll32.exe user32.dll,LockWorkStation','2015-05-10 21:25:06',1,'锁定计算机'),('46217c6d44354010823241ef484f7214','打开浏览器','C:/Program Files/Internet Explorer/iexplore.exe','2015-05-09 02:43:02',1,'打开浏览器操作'),('576adcecce504bf3bb34c6b4da79a177','关闭浏览器','taskkill /f /im iexplore.exe','2015-05-09 02:36:48',1,'关闭浏览器操作'),('854a157c6d99499493f4cc303674c01f','关闭QQ','taskkill /f /im qq.exe','2015-05-10 21:25:46',1,'关闭QQ'),('ab3a8c6310ca4dc8b803ecc547e55ae7','打开QQ','D:/SOFT/QQ/QQ/Bin/qq.exe','2015-05-10 21:25:25',1,'打开QQ');

/*Table structure for table `weixin_imgmsg` */

DROP TABLE IF EXISTS `weixin_imgmsg`;

CREATE TABLE `weixin_imgmsg` (
  `IMGMSG_ID` varchar(100) NOT NULL,
  `KEYWORD` varchar(255) DEFAULT NULL COMMENT '关键词',
  `CREATETIME` varchar(255) DEFAULT NULL COMMENT '创建时间',
  `STATUS` int(11) NOT NULL COMMENT '状态',
  `BZ` varchar(255) DEFAULT NULL COMMENT '备注',
  `TITLE1` varchar(255) DEFAULT NULL COMMENT '标题1',
  `DESCRIPTION1` varchar(255) DEFAULT NULL COMMENT '描述1',
  `IMGURL1` varchar(255) DEFAULT NULL COMMENT '图片地址1',
  `TOURL1` varchar(255) DEFAULT NULL COMMENT '超链接1',
  `TITLE2` varchar(255) DEFAULT NULL COMMENT '标题2',
  `DESCRIPTION2` varchar(255) DEFAULT NULL COMMENT '描述2',
  `IMGURL2` varchar(255) DEFAULT NULL COMMENT '图片地址2',
  `TOURL2` varchar(255) DEFAULT NULL COMMENT '超链接2',
  `TITLE3` varchar(255) DEFAULT NULL COMMENT '标题3',
  `DESCRIPTION3` varchar(255) DEFAULT NULL COMMENT '描述3',
  `IMGURL3` varchar(255) DEFAULT NULL COMMENT '图片地址3',
  `TOURL3` varchar(255) DEFAULT NULL COMMENT '超链接3',
  `TITLE4` varchar(255) DEFAULT NULL COMMENT '标题4',
  `DESCRIPTION4` varchar(255) DEFAULT NULL COMMENT '描述4',
  `IMGURL4` varchar(255) DEFAULT NULL COMMENT '图片地址4',
  `TOURL4` varchar(255) DEFAULT NULL COMMENT '超链接4',
  `TITLE5` varchar(255) DEFAULT NULL COMMENT '标题5',
  `DESCRIPTION5` varchar(255) DEFAULT NULL COMMENT '描述5',
  `IMGURL5` varchar(255) DEFAULT NULL COMMENT '图片地址5',
  `TOURL5` varchar(255) DEFAULT NULL COMMENT '超链接5',
  `TITLE6` varchar(255) DEFAULT NULL COMMENT '标题6',
  `DESCRIPTION6` varchar(255) DEFAULT NULL COMMENT '描述6',
  `IMGURL6` varchar(255) DEFAULT NULL COMMENT '图片地址6',
  `TOURL6` varchar(255) DEFAULT NULL COMMENT '超链接6',
  `TITLE7` varchar(255) DEFAULT NULL COMMENT '标题7',
  `DESCRIPTION7` varchar(255) DEFAULT NULL COMMENT '描述7',
  `IMGURL7` varchar(255) DEFAULT NULL COMMENT '图片地址7',
  `TOURL7` varchar(255) DEFAULT NULL COMMENT '超链接7',
  `TITLE8` varchar(255) DEFAULT NULL COMMENT '标题8',
  `DESCRIPTION8` varchar(255) DEFAULT NULL COMMENT '描述8',
  `IMGURL8` varchar(255) DEFAULT NULL COMMENT '图片地址8',
  `TOURL8` varchar(255) DEFAULT NULL COMMENT '超链接8',
  PRIMARY KEY (`IMGMSG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `weixin_imgmsg` */

insert  into `weixin_imgmsg`(`IMGMSG_ID`,`KEYWORD`,`CREATETIME`,`STATUS`,`BZ`,`TITLE1`,`DESCRIPTION1`,`IMGURL1`,`TOURL1`,`TITLE2`,`DESCRIPTION2`,`IMGURL2`,`TOURL2`,`TITLE3`,`DESCRIPTION3`,`IMGURL3`,`TOURL3`,`TITLE4`,`DESCRIPTION4`,`IMGURL4`,`TOURL4`,`TITLE5`,`DESCRIPTION5`,`IMGURL5`,`TOURL5`,`TITLE6`,`DESCRIPTION6`,`IMGURL6`,`TOURL6`,`TITLE7`,`DESCRIPTION7`,`IMGURL7`,`TOURL7`,`TITLE8`,`DESCRIPTION8`,`IMGURL8`,`TOURL8`) values ('380b2cb1f4954315b0e20618f7b5bd8f','首页','2015-05-10 20:51:09',1,'图文回复','图文回复标题','图文回复描述','http://a.hiphotos.baidu.com/image/h%3D360/sign=c6c7e73ebc389b5027ffe654b535e5f1/a686c9177f3e6709392bb8df3ec79f3df8dc55e3.jpg','www.baidu.com','','','','','','','','','','','','','','','','','','','','','','','','','','','','');

/*Table structure for table `weixin_textmsg` */

DROP TABLE IF EXISTS `weixin_textmsg`;

CREATE TABLE `weixin_textmsg` (
  `TEXTMSG_ID` varchar(100) NOT NULL,
  `KEYWORD` varchar(255) DEFAULT NULL COMMENT '关键词',
  `CONTENT` varchar(255) DEFAULT NULL COMMENT '内容',
  `CREATETIME` varchar(255) DEFAULT NULL COMMENT '创建时间',
  `STATUS` int(11) DEFAULT NULL COMMENT '状态',
  `BZ` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`TEXTMSG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `weixin_textmsg` */

insert  into `weixin_textmsg`(`TEXTMSG_ID`,`KEYWORD`,`CONTENT`,`CREATETIME`,`STATUS`,`BZ`) values ('303c190498a045bdbba4c940c2f0d9f9','1ss','1ssddd','2015-05-18 20:17:02',1,'1ssdddsd'),('695cd74779734231928a253107ab0eeb','吃饭','吃了噢噢噢噢','2015-05-10 22:52:27',1,'文本回复'),('d4738af7aea74a6ca1a5fb25a98f9acb','关注','关注','2015-05-11 02:12:36',1,'关注回复');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

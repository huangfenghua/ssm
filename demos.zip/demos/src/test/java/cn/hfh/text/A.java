package cn.hfh.text;

import java.util.TreeMap;

public class A {
	public static void main(String[] args) {
		TreeMap<String,String> map = new TreeMap<String,String>();
		map.put("account", "cj");
		map.put("bankCard", "6225768752000000");
		map.put("idCard", "370725199212000000");
		map.put("mobile", "13810000000");
		map.put("name", "张三");
		map.put("orderNo", "3413131432135135");//订单号
		map.put("sign", "5yASDYLHRLDSEQ2%2BXH7QhPp2aq0%3D");//签名，请参照文档第八项生成签名
		
		HttpJsonUrl ac = new Httpjsonurl("http://api.hihippo.cn/api/bankcardFour");
		String json  = JSONUtil.parseObj(map).toString();
		String url = "http://api.hihippo.cn/api/bankcardFour";//以4.1.1中的API地址为准
		String result2 = HttpRequest.post(url).charset("UTF-8").
						contentType("application/json;charset=UTF-8").body(json).execute().body();
		System.out.println(json);
	}
}

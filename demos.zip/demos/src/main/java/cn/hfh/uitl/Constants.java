package cn.hfh.uitl;

public class Constants {
	public final static String USER_SESSION = "userSession";
	public final static String SYS_MESSAGE = "message";
	public final static String SESSION_KEY_OF_RAND_CODE= "codes";
	public final static String ROLE_SESSION = "role";
	
	public final static int pageSize = 5;
}

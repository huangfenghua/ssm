package cn.hfh.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.hfh.entity.Bank;
import cn.hfh.entity.Role;
import cn.hfh.entity.User;
import cn.hfh.uitl.PageData;

public interface UserMapper {
	
	public User getUser(@Param("userName") String userClode);

	public List<User> select_list(@Param("user") User user);

	public int add(@Param("user") User user);
	
	public int updateUser(@Param("user") User user);
	
	public int deleteuser(@Param("id") Integer id);

	public void updatepwd(@Param("id") Integer id, @Param("userPassword")String userPassword);

	public void deleteAllUcs(@Param("id")Integer id);

	public void addUser(Bank bank);

	public List<Bank> select_bank(@Param("bank")Bank bank);

	public void update_bank(@Param("bank")Bank bank);
	
	public List<Role> select_role(@Param("role")Role role);
	
	public void update_user(@Param("bank")Bank bank);

	
	
}

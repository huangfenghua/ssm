package cn.hfh.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.hfh.entity.Menu;
import cn.hfh.entity.Role;
import cn.hfh.entity.User;

public interface RoleMapper {

	public Role select_role_getrole(@Param("user") User user);

	public List<Menu> listAllParentMenu();

	public List<Menu> listSubMenuByParentId(String parentId);

	public Role getRoleById(String rOLE_ID);
	public List<Menu> listAllParentMenus(@Param("menu") Menu menu);

	public String getByid(String rOLE_ID);

	public void ztreeUpdate(Map<String, String> map);

	public void update_name(Map<String, String> map);

	public void add_ztree(Map<String, String> map);
	
}

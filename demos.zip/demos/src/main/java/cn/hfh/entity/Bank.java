package cn.hfh.entity;

import org.springframework.web.multipart.MultipartFile;

public class Bank {
	private String id;
	private String username ;
	private String u_id;
	private String bankCard;
	private Integer USEr_ID;
	private String  fu_img;//身份证图片
	private String  fb_img;//银行图片
	private MultipartFile  fuimg;//身份证图片
	private MultipartFile  fbimg;//银行图片
	private String statu;
	private String phone;
	
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getBankCard() {
		return bankCard;
	}
	public void setBankCard(String bankCard) {
		this.bankCard = bankCard;
	}
	public Integer getUSEr_ID() {
		return USEr_ID;
	}
	public void setUSEr_ID(Integer uSEr_ID) {
		USEr_ID = uSEr_ID;
	}
	public String getFu_img() {
		return fu_img;
	}
	public void setFu_img(String fu_img) {
		this.fu_img = fu_img;
	}
	public String getFb_img() {
		return fb_img;
	}
	public void setFb_img(String fb_img) {
		this.fb_img = fb_img;
	}
	public MultipartFile getFuimg() {
		return fuimg;
	}
	public void setFuimg(MultipartFile fuimg) {
		this.fuimg = fuimg;
	}
	public MultipartFile getFbimg() {
		return fbimg;
	}
	public void setFbimg(MultipartFile fbimg) {
		this.fbimg = fbimg;
	}
	public String getStatu() {
		return statu;
	}
	public void setStatu(String statu) {
		this.statu = statu;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

}

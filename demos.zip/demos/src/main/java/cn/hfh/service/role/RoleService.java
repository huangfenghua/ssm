package cn.hfh.service.role;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.hfh.dao.RoleMapper;
import cn.hfh.dao.UserMapper;
import cn.hfh.entity.Menu;
import cn.hfh.entity.Role;
import cn.hfh.entity.User;

@Service("roleService")
public class RoleService{
	@Resource
	private RoleMapper rolemapper;

	//查询权限
	public Role getRole(User user) {
		return rolemapper.select_role_getrole(user);
	}


	public List<Menu> listAllParentMenu() {
		return rolemapper.listAllParentMenu();
	}
	
	public List<Menu> listSubMenuByParentId(String parentId) {
		return rolemapper.listSubMenuByParentId(parentId);
	}
	public List<Menu> listAllMenu() {

		List<Menu> rl = this.listAllParentMenu();
		for(Menu menu : rl){
			List<Menu> subList = this.listSubMenuByParentId(menu.getMENU_ID());
			menu.setSubMenu(subList);
		}
		return rl;
	}
	
	

	public void ztreeUpdate(String ids,String rid) {
		Map<String, String> map = new HashMap<>();
		map.put("RIGHTS", ids);
		map.put("ROLE_ID", rid);
		rolemapper.ztreeUpdate(map);
	}

	public Role getRoleById(String rOLE_ID) {
		return rolemapper.getRoleById(rOLE_ID);
	}


	public List<Menu> listAllParentMenus(Menu menu) {
		return rolemapper.listAllParentMenus(menu);
	}


	public String getByid(String rOLE_ID) {
		return rolemapper.getByid(rOLE_ID);
	}


	public void update_name(String rOLE_Name, String rOLE_ID) {
		Map<String, String> map = new HashMap<>();
		map.put("ROLE_NAME", rOLE_Name);
		map.put("ROLE_ID", rOLE_ID);
		rolemapper.update_name(map);
		
	}


	public void add_ztree(String ids, String rOLE_Name) {
		Map<String, String> map = new HashMap<>();
		map.put("ROLE_NAME", rOLE_Name);
		map.put("RIGHTS", ids);
		rolemapper.add_ztree(map);
	}

}

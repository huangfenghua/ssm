package cn.hfh.service;

import java.sql.Date;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.hfh.dao.UserMapper;
import cn.hfh.entity.Bank;
import cn.hfh.entity.Role;
import cn.hfh.entity.User;
import cn.hfh.uitl.MD5;
import cn.hfh.uitl.PageData;
import cn.hfh.uitl.httpPost;
import net.sf.json.JSONObject;

@Service(value="userService")
public class UserServiceImpl{

	
	@Resource
	private UserMapper usermapper;
	
	
	
	/*
	*用户列表(用户组)
	*/
/*	public List<PageData> listPdPageUser()throws Exception{
		return (List<PageData>) usermapper.findForList("UserXMapper.userlistPage",null);
	}*/
	
	
	public List<User> select_list(User pd)throws Exception{
		return usermapper.select_list(pd);
	}
	
	public void deleteAllUcs(Integer pd) throws Exception {
		usermapper.deleteAllUcs(pd);
		
	}
	
	
	public void updatepwd(Integer pd,String pass) throws Exception {
		usermapper.updatepwd(pd,pass);
		
	}

	public JSONObject addUser(Bank bank) {
		String data = httpPost.isHttpBank(bank);
		JSONObject jsonObject = JSONObject.fromObject(data);
		String code = jsonObject.getString("msg");
		
		//成功
		if(code.equals("success")){
			/*二次判断
			 * String _code = jsonObject.getString("data");
			JSONObject sc = JSONObject.fromObject(_code);
			String identifyCode = sc.getString("identifyCode");
			if(identifyCode=="0000"){*/
				usermapper.addUser(bank);
				System.out.println("进行处理￥￥￥￥￥￥￥");
			/*	return jsonObject;
			}*/
			
			return jsonObject;
		}else {
			return jsonObject;
		}
		
		
	}

	public List<Bank> select_bank(Bank bank) {
		return usermapper.select_bank(bank);
	}

	public void update_bank(Bank bank) {
		List<Bank> list =  select_bank(bank);
		usermapper.update_bank(bank);
		Bank _bank = list.get(0);
		_bank.setStatu(bank.getStatu());
		usermapper.update_user(_bank);
	}
	
	public List<Role> select_role(Role bank) {
		return usermapper.select_role(bank);
	}

	public void deleteuser(Integer id) {
		usermapper.deleteuser(id);
	}

	public void add(User user) {
		user.setBirthday(new java.sql.Date(1));
		user.setUserPassword(MD5.md5(user.getUserPassword()));
		usermapper.add(user);
	}

	public void updateUser(User user) {
		usermapper.updateUser(user);
	}

	public User getUser(String userClode, String password) {
		User user = usermapper.getUser(userClode);
		if(null != user){
			if(!MD5.md5(password).equals(user.getUserPassword())){
				user = null;
			}
		}
		return user;
	}

	

	
}

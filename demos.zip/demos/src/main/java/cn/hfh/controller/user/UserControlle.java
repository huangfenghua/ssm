package cn.hfh.controller.user;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.Spring;

import org.apache.ibatis.annotations.Param;
import org.omg.CORBA.PUBLIC_MEMBER;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import cn.hfh.controller.besa.BaseController;
import cn.hfh.entity.Bank;
import cn.hfh.entity.Menu;
import cn.hfh.entity.Role;
import cn.hfh.entity.User;
import cn.hfh.service.UserServiceImpl;
import cn.hfh.service.role.RoleService;
import cn.hfh.uitl.Constants;
import cn.hfh.uitl.MD5;
import cn.hfh.uitl.RightsHelper;
import cn.hfh.uitl.Tools;


@Controller
public class UserControlle extends  BaseController{
	@Resource(name="roleService")
	private RoleService roleService;

	@Resource(name = "userService")
	private UserServiceImpl userService;

	@RequestMapping(value="/login")
	public String tologin(){
		return "login";
	}


	@RequestMapping(value="/sys/role_list")
	public String torole(){
		return "role_list";
	}

	@RequestMapping(value="/sys/sysrz")
	public String syslogin(){
		return "syslogin";
	}

	@RequestMapping(value="/sys/setprivis")
	public String topwd(){
		return "setPrivilegeUI";
	}
	@RequestMapping(value="/sys/setprivi")
	public ModelAndView tosetprivipwd(HttpSession session,HttpServletResponse response,ModelAndView mv) throws IOException{
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		List<Role> role = userService.select_role(new Role());
		List<Menu> menus = roleService.listAllParentMenus(new Menu());
		List<JSONObject> lArray = new ArrayList<>();
		lArray.addAll(JSONArray.fromObject(menus));
		StringBuffer bf = new StringBuffer();
		bf.append("[");
		String pid = null;
		String id = null;
		String cname = null;
		for (JSONObject menu : lArray) {
			pid = menu.getString("PARENT_ID");
			id = menu.getString("MENU_ID");
			cname = menu.getString("MENU_NAME");
			// 判断一级菜单
			if (pid.equals("0")) {

				bf.append("{\"id\":"+"\""+id+"\","+"\"pId\":"+"\""+pid+"\","+"\"name\":"+"\""+cname+"\","+"\"open\":false},");
			} else {
				bf.append("{\"id\":"+"\""+id+"\","+"\"pId\":"+"\""+pid+"\","+"\"name\":"+"\""+cname+"\","+"\"open\":true},");
			}
		}
		String menuStr = "";
		if (bf.length() > 0) {
			menuStr = bf.substring(0, bf.length()-1);
		}
		menuStr += "]";
		System.out.println("数据公司 "+JSON.toJSONString(role));
		/*response.getWriter().print(JSON.toJSONString(role));*/
		Map<Object, Object> _menuStr = new HashMap<>();
		_menuStr.put("pid","0");
		_menuStr.put("id","22");
		_menuStr.put("name","部门管理");

		_menuStr.put("pid","22");
		_menuStr.put("id","23");
		_menuStr.put("name","认证管理");
		//加载数
		mv.addObject("dataz", menuStr);
		//设置数选中
		mv.addObject("datax", JSONObject .fromObject(_menuStr));
		mv.setViewName("setPrivilegeUI");
		return mv;
	}


	@RequestMapping(value="/dologin",method=RequestMethod.POST)
	public ModelAndView doLogin(@RequestParam String username,@RequestParam String password,@RequestParam String VerificationCode,HttpServletRequest request,HttpSession session,ModelAndView m) throws Exception{
		String code = ((String) session.getAttribute(Constants.SESSION_KEY_OF_RAND_CODE)).toLowerCase();
		session.removeAttribute(Constants.SYS_MESSAGE);
		//		VerificationCode
		if(Tools.isEmpty(code)){
			session.setAttribute(Constants.SYS_MESSAGE, "验证码不能为空");
			//			VerificationCode.toLowerCase()
		}else if(!code.equals(code)){
			session.setAttribute(Constants.SYS_MESSAGE, "验证码错误");
		}else {
			//			username, password
			User user = userService.getUser("admin", "111111");
			if(null != user){
				Role role = roleService.getRole(user);
				session.setAttribute(Constants.USER_SESSION, user);
				session.setAttribute(Constants.ROLE_SESSION, role);//放入权限
				m.setViewName("admin_main");
				return m;
			}
			session.setAttribute(Constants.SYS_MESSAGE, "用户名或者密码错误");
		}
		m.setViewName("login");
		return m;
	}

	@RequestMapping("/sys/logout")
	public String loginout(HttpSession session){
		session.removeAttribute(Constants.USER_SESSION);
		session.removeAttribute(Constants.SYS_MESSAGE);
		return "redirect:/login";
	}

	/*@RequestMapping("/sys/select_user")
	public ModelAndView selectList(ModelAndView view,User user){
		List<User> users= userService.select_list(user);
		view.addObject("data",users);
		view.setViewName("demo");
		return view;
	}
	 */

	/**
	 * 去系统管理页面
	 */
	@RequestMapping(value="/sys/user_list")
	public ModelAndView user_list(User user)throws Exception{
		ModelAndView mv = new ModelAndView();
		List<User> users= userService.select_list(user);
		mv.addObject("data",users);
		mv.setViewName("user_list");
		return mv;
	}

	@RequestMapping(value="/sys/user_bank")
	public ModelAndView user_bank(Bank bank)throws Exception{
		ModelAndView mv = new ModelAndView();
		List<Bank> users= userService.select_bank(bank);
		mv.addObject("data",users);
		mv.setViewName("user_bank");
		return mv;
	}

	@RequestMapping(value="/sys/user_role")
	public ModelAndView user_bank(Role role,HttpSession session,HttpServletResponse response)throws Exception{
		ModelAndView mv = new ModelAndView();
		List<Role> users= userService.select_role(role);
		mv.addObject("data",users);
		/*	this.tosetprivipwd(session,response,mv);*/

		mv.setViewName("role_list");
		return mv;
	}



	@RequestMapping(value="/sys/deletepasswod")
	public ModelAndView deletepasswod(Integer USER_IDS) throws Exception{
		ModelAndView mv = new ModelAndView();
		userService.updatepwd(USER_IDS,MD5.md5("111111"));
		mv.setViewName("redirect:/sys/user_list");
		return mv;
	}

	/**
	 * 去真假管理页面
	 */
	@RequestMapping(value="/sys/getaddUser")
	public ModelAndView getuser()throws Exception{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("user_add");
		return mv;
	}



	@RequestMapping(value="/sys/getrz")
	public ModelAndView getrz(Bank bank)throws Exception{
		ModelAndView mv = new ModelAndView();
		List<Bank> users= userService.select_bank(bank);
		mv.addObject("bank",users.get(0));
		mv.setViewName("user_edit");
		return mv;
	}

	@RequestMapping(value="/sys/Drz")
	public ModelAndView Drz(Bank bank)throws Exception{
		ModelAndView mv = new ModelAndView();
		userService.update_bank(bank);
		mv.setViewName("redirect:/sys/user_bank");
		return mv;
	}



	@RequestMapping(value="/sys/getadd")
	public ModelAndView getadd(User user)throws Exception{
		ModelAndView mv = new ModelAndView();
		userService.add(user);
		mv.setViewName("redirect:/sys/user_list");
		return mv;
	}


	@RequestMapping(value="/sys/getUpdatedo")
	public ModelAndView getUpdatedo(User user)throws Exception{
		ModelAndView mv = new ModelAndView();
		List<User> users= userService.select_list(user);
		User _user = users.get(0);
		mv.addObject("pd", _user);
		mv.setViewName("user_add");
		return mv;
	}


	@RequestMapping(value="/sys/getUpdate")
	public ModelAndView getUpdate(@Param("user") User user)throws Exception{
		ModelAndView mv = new ModelAndView();
		userService.updateUser(user);
		mv.setViewName("redirect:/sys/user_list");
		return mv;
	}


	@RequestMapping(value="/sys/deleteUser")
	public ModelAndView deleteuser(@Param("id") Integer id)throws Exception{
		ModelAndView mv = new ModelAndView();
		userService.deleteuser(id);
		mv.setViewName("redirect:/sys/user_list");
		return mv;
	}

	/*@ResponseBody
	@RequestMapping(value="/sys/equerpw",method=RequestMethod.POST)
	public Object equerpw(@Param("paw") String paw,HttpSession session)throws Exception{
		Map<Object, Object> map = new HashMap<Object, Object>();

		User user = (User) session.getAttribute(Constants.USER_SESSION);
		if(user.getUserPassword().equals(paw)){
			map.put("re", "yes");
		}else{
			map.put("re", "no");
		}
		return JSON.toJSONString(map);
	}

	@RequestMapping(value="/sys/updatepwd")
	public ModelAndView updatepwd(@Param("id") Integer id,@Param("userPasswords") String userPasswords)throws Exception{
		System.out.println(userPasswords);
		ModelAndView mv = new ModelAndView();
		userService.updatepwd(id,userPasswords);
		mv.setViewName("redirect:/sys/logout");
		return mv;
	}*/

	@RequestMapping(value="/sys/pictures_list")
	public String pictures_list(){
		return "pictures_list";
	}

	@RequestMapping("/sys/upload")
	@ResponseBody
	public Object upload(Bank bank,HttpServletRequest request,Model model,HttpSession session) throws Exception{  
		System.out.println(request.getParameter("username"));  
		//保存数据库的路径  
		String sqlPath = null;
		String _sqlPath = null;   
		//定义文件保存的本地路径  
		String localPath = 
				request.getSession().getServletContext().getRealPath("/static/images/");
		//定义 文件名  
		String filename=null;  
		String _filename=null;
		if(!bank.getFuimg().isEmpty()&&!bank.getFbimg().isEmpty()){    
			//生成uuid作为文件名称    
			String uuid = UUID.randomUUID().toString().replaceAll("-","");
			String _uuid = UUID.randomUUID().toString().replaceAll("-","");    
			//获得文件类型（可以判断如果不是图片，禁止上传）    
			String contentType=bank.getFuimg().getContentType();
			String _contentType=bank.getFbimg().getContentType(); 
			//获得文件后缀名   
			String suffixName=contentType.substring(contentType.indexOf("/")+1);  
			String _suffixName=_contentType.substring(contentType.indexOf("/")+1); 
			//得到 文件名  
			filename=uuid+"."+suffixName; 
			_filename=_uuid+"."+_suffixName;   
			System.out.println("1111.u"+filename);  
			System.out.println("2222.b"+_filename);  
			//文件保存路径  
			bank.getFuimg().transferTo(new File(localPath+filename)); 
			bank.getFbimg().transferTo(new File(localPath+_filename));
		}  
		//把图片的相对路径保存至数据库  
		sqlPath = "/images/"+filename;
		_sqlPath = "/images/"+_filename;  
		System.out.println(sqlPath);
		bank.setId(get32UUID());
		bank.setFu_img(sqlPath);
		bank.setFb_img(_sqlPath);
		bank.setUSEr_ID(((User)session.getAttribute(Constants.USER_SESSION)).getId());
		System.out.println("输出的id___________"+((User)session.getAttribute(Constants.USER_SESSION)).getId());
		return userService.addUser(bank);
	}  


	/**
	 * 请求角色菜单授权页面
	 */
	@RequestMapping(value="/sys/auth")
	public ModelAndView auth(@RequestParam String ROLE_ID,HttpServletResponse response,ModelAndView mv)throws Exception{
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		String _rights = roleService.getByid(ROLE_ID);
		if(!_rights.equals(null)){
			String[] list = _rights.split("\\,");
			StringBuffer _bf = new StringBuffer();
			_bf.append("[");
			for (String string : list) {
				_bf.append("{\"id\":"+"\""+string+"\"},");
			}
			String _menuStr = "";
			if (_bf.length() > 0) {
				_menuStr = _bf.substring(0, _bf.length()-1);
			}
			_menuStr += "]";
			System.out.println(list[0]+"///"+list.length);
			Map<Object, Object> map =new HashMap<>();
			map.put("datas", _menuStr);
			mv.addObject("map", map);
		}
		List<Role> roles = userService.select_role(new Role());
		List<Menu> menus = roleService.listAllParentMenus(new Menu());
		List<JSONObject> lArray = new ArrayList<>();
		lArray.addAll(JSONArray.fromObject(menus));
		StringBuffer bf = new StringBuffer();
		bf.append("[");
		String pid = null;
		String id = null;
		String cname = null;
		for (JSONObject menu : lArray) {
			pid = menu.getString("PARENT_ID");
			id = menu.getString("MENU_ID");
			cname = menu.getString("MENU_NAME");
			// 判断一级菜单
			if (pid.equals("0")) {

				bf.append("{\"id\":"+"\""+id+"\","+"\"pId\":"+"\""+pid+"\","+"\"name\":"+"\""+cname+"\","+"\"open\":false},");
			} else {
				bf.append("{\"id\":"+"\""+id+"\","+"\"pId\":"+"\""+pid+"\","+"\"name\":"+"\""+cname+"\","+"\"open\":true},");
			}
		}
		String menuStr = "";
		if (bf.length() > 0) {
			menuStr = bf.substring(0, bf.length()-1);
		}
		menuStr += "]";
		System.out.println("数据公司 "+JSON.toJSONString(roles));
		/*response.getWriter().print(JSON.toJSONString(role));*/
		//加载数
		mv.addObject("dataz", menuStr);
		mv.addObject("ROLE_ID", ROLE_ID);
		mv.setViewName("setPrivilegeUI");
		return mv;
	}
	
	
	
	/**
	 * 请求角色菜单授权页面
	 */
	@RequestMapping(value="/sys/auths")
	public ModelAndView auth(HttpServletResponse response,ModelAndView mv)throws Exception{
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		List<Role> roles = userService.select_role(new Role());
		List<Menu> menus = roleService.listAllParentMenus(new Menu());
		List<JSONObject> lArray = new ArrayList<>();
		lArray.addAll(JSONArray.fromObject(menus));
		StringBuffer bf = new StringBuffer();
		bf.append("[");
		String pid = null;
		String id = null;
		String cname = null;
		for (JSONObject menu : lArray) {
			pid = menu.getString("PARENT_ID");
			id = menu.getString("MENU_ID");
			cname = menu.getString("MENU_NAME");
			// 判断一级菜单
			if (pid.equals("0")) {

				bf.append("{\"id\":"+"\""+id+"\","+"\"pId\":"+"\""+pid+"\","+"\"name\":"+"\""+cname+"\","+"\"open\":false},");
			} else {
				bf.append("{\"id\":"+"\""+id+"\","+"\"pId\":"+"\""+pid+"\","+"\"name\":"+"\""+cname+"\","+"\"open\":true},");
			}
		}
		String menuStr = "";
		if (bf.length() > 0) {
			menuStr = bf.substring(0, bf.length()-1);
		}
		menuStr += "]";
		System.out.println("数据公司 2"+JSON.toJSONString(roles));
		//加载数
		mv.addObject("dataz", menuStr);
		mv.setViewName("setPrivilegeUIAdd");
		return mv;
	}
	
	
	@RequestMapping("/sys/update_ztree")
	public ModelAndView authZtree(@RequestParam("ids") String ids,@RequestParam("ROLE_ID") String ROLE_ID){
		ModelAndView mv = this.getModelAndView();
		ids = ids.substring(0, ids.length()-1);
		System.out.println(ids+"测试"+ROLE_ID);
		roleService.ztreeUpdate(ids,ROLE_ID);
		mv.setViewName("redirect:/sys/user_role");
		return mv;
	}
	
	@RequestMapping("/sys/update_name")
	public ModelAndView update_name(@RequestParam("ROLE_Name") String ROLE_Name,@RequestParam("ROLE_ID") String ROLE_ID){
		ModelAndView mv = this.getModelAndView();
		System.out.println(ROLE_Name+"测试"+ROLE_ID);
		roleService.update_name(ROLE_Name,ROLE_ID);
		mv.setViewName("redirect:/sys/user_role");
		return mv;
	}
	
	@RequestMapping("/sys/add_ztree")
	public ModelAndView add_ztree(@RequestParam("ids") String ids,@RequestParam("ROLE_Name") String ROLE_Name){
		ModelAndView mv = this.getModelAndView();
		ids = ids.substring(0, ids.length()-1);
		System.out.println(ids+"测试"+ROLE_Name);
		roleService.add_ztree(ids,ROLE_Name);
		mv.setViewName("redirect:/sys/user_role");
		return mv;
	}
	
}
